#!/usr/bin/env python
# -*- coding: utf-8 -*-

__version__ = "0.0.8"

# from KeyWordsExtractions.Current_Density import *
from KeyWordsExtractions.Extracting_Informations import Converting_From_PDF_OR_XML_To_TXT,\
    Filtring_And_Checking_Keywords
# from KeyWordsExtractions.Filtring_Functions import *